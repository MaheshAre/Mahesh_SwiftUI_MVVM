//
//  LoginView.swift
//  SwiftUIMVVM
//
//  Created by IC-MAC004 on 3/24/21.
//

import SwiftUI

struct LoginView: View {
    
    @State var isShowPassword = false
    
    @State var isNavigatingHome = false
    @ObservedObject var vmLogin = VMLogin()
    
    @State var tabBar: UITabBar? = nil
        
//    @State var isShowBackBtn = false
                                
    var body: some View {
        
        //        NavigationView {
        
        VStack(alignment: .center, spacing: 15, content: {
            
            CustomTextField(PlaceHolder: "Custom TextField", BindingString: self.$vmLogin.params.username)
            
            ZStack(alignment: Alignment(horizontal: .trailing, vertical: .center), content: {
                
                CustomSecureTextField(PlaceHolder: "Password", BindingString: self.$vmLogin.params.password, RightPadding: 50)
                Button("   ") {
                    withAnimation() {
                        self.isShowPassword.toggle()
                        self.endEditing()
                    }
                    
                }
                .padding()
                .background(self.isShowPassword ? Image("icon_show") : Image("icon_hide"))
                
            })
            
            //                if self.isShowPassword {
            //                    Text("Password: \(self.vmLogin.params.password)")
            //                }else {
            //                    Text("")
            //                }
            
            //MARK:- Login Button
            
            LoginBtnView(isNavigatingHome: self.isNavigatingHome, vmLogin: self.vmLogin)
            
        })
        .frame(maxWidth: screenWidth-30, maxHeight: .infinity, alignment: .top)
        .navigationTitle("Login")
        .padding()

    }
}

struct LoginView_Previews: PreviewProvider {
    static var previews: some View {
        LoginView()
    }
}

struct LoginBtnView: View {
    
    @State var isNavigatingHome = false
    @ObservedObject var vmLogin = VMLogin()
        
    var body: some View {
        
        NavigationLink(
            destination: HomeTabView(),
            isActive: self.$isNavigatingHome) { EmptyView() }
        
        Button(action: {
                        
            if self.isValideParams() {
                
                self.vmLogin.serivce_login(onCompletion: { isSuccess,errorMsg  in
//                    if let error = errorMsg {
//                        CustomAlertController.showAlertController(message: error, actionTitle: "Ok")
//                    }
                    if isSuccess {
                        self.isNavigatingHome = true
                    }
                })
                
            }
            
        }, label: {
            Text("Login")
        })
        .defaultStyle()
        .padding(.top, 5)
        
        
    }
    
    func isValideParams() -> Bool {
        
        var boolValue = true
                
        if self.vmLogin.params.username.isValid_Email() == false {
            CustomToast.showToast(Message: "Please enter valid Email-Id")
            boolValue = false
        }else if self.vmLogin.params.password.isValid_TF(count: 6) == false {
//            self.isPasswordToast = true
            
            CustomToast.showToast(Message: "Please enter valid Password")
            
            boolValue = false
        }
        
        return boolValue
    }
}
