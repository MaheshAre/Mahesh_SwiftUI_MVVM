//
//  InvoiceView.swift
//  SwiftUIMVVM
//
//  Created by IC-MAC004 on 3/25/21.
//

import SwiftUI

struct InvoiceView: View {
    
    @ObservedObject var vmInvoice = VMInvoice()
    
    
    init() {
        
        UITableView.appearance().tableHeaderView = UIView(frame: CGRect(x: 0, y: 0, width: 0, height: Double.leastNonzeroMagnitude))
        UITableView.appearance().separatorColor = .white
    }
    
    var body: some View {
        
        VStack(alignment: .center, spacing: 5, content: {
                        
            HStack(alignment: .center, spacing: nil, content: {
                
                self.headingTextStyle(text: "  Invoice No")
                
                self.headingTextStyle(text: "Customer Name")
                
                self.headingTextStyle(text: "Date", Alignment: .center)
                
                self.headingTextStyle(text: "Amount", Alignment: .leading)
                
            })
            .padding(5)
            Text("")
                .frame(maxWidth: .infinity, maxHeight: 0.5, alignment: .center)
                .background(UIColor.lightGray.toColor())
            
            //List
            List(self.vmInvoice.invoiceArray, id: \.Id) { (data) in
                
                HStack {

                    listDataTextStyle(text: data.VNo, Alignment: .leading)

                    listDataTextStyle(text: data.ContactName, Alignment: .leading)

                    listDataTextStyle(text: data.VDate, Alignment: .center)

                    listDataTextStyle(text: data.TotalAmount?.toStringFormat(FractionDigits: 2), Alignment: .leading)
                }
            }
            .padding(.leading, -16)
            .padding(.trailing, -20)
            .listSeparatorStyleNone()
            
            
        })
        .frame(maxWidth: .infinity,maxHeight: .infinity, alignment: .top)
        .navigationTitle("Invoices")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear() {
            self.vmInvoice.service_invoice()
        }

    }
    
    
    func headingTextStyle(text: String?, Alignment alignment: Alignment = .leading) -> some View {
        
        return customText(Text: text ?? "", FontName: .System_semibold, FontSize: 15, TextColor: .red, Alignment: alignment, CornerRadius: 0, BorderWidth: 0)
    }
    
    func listDataTextStyle(text: String?, Alignment alignment: Alignment = .leading) -> some View {
        
        return customText(Text: text ?? "", FontName: .System_regular, FontSize: 14, TextColor: .black, Alignment: alignment, CornerRadius: 0, BorderWidth: 0)
    }
    
}



struct InvoiceView_Previews: PreviewProvider {
    static var previews: some View {
        InvoiceView()
    }
}


public struct ListSeparatorStyleNoneModifier: ViewModifier {
    public func body(content: Content) -> some View {
        content.onAppear {
            UITableView.appearance().separatorStyle = .none
        }.onDisappear {
            UITableView.appearance().separatorStyle = .singleLine
        }
    }
}

// now let's make a small extension that would help to hide the details
 
extension View {
    public func listSeparatorStyleNone() -> some View {
        modifier(ListSeparatorStyleNoneModifier())
    }
}
