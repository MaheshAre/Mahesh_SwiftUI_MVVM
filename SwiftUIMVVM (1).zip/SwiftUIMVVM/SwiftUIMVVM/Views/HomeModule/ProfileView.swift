//
//  ProfileView.swift
//  SwiftUIMVVM
//
//  Created by IC-MAC004 on 3/25/21.
//

import SwiftUI

struct ProfileView: View {
    var body: some View {
        
        VStack(alignment: .leading, spacing: 8, content: {
            
            HStack(alignment: .center, spacing: 5, content: {
                default_TextHeading(Text: "Emp ID:")
                default_Text(Text: "\(user_defaults.value(forKey: Enum_UserData.UserId.rawValue) as? String ?? "")")
                
            })
            HStack(alignment: .center, spacing: 5, content: {
                default_TextHeading(Text: "Username:")
                default_Text(Text: "\(user_defaults.value(forKey: Enum_UserData.UserName.rawValue) as? String ?? "")")
            })
            HStack(alignment: .center, spacing: 5, content: {
                default_TextHeading(Text: "Company Ids:")
                default_Text(Text: "\(user_defaults.value(forKey: Enum_UserData.Companies.rawValue) as? String ?? "")")
    
            })
            
            NavigationButton(destination: {
                BlendView()
            }, label: {
                Text("BlendView")
                    .setCustomViewStyle(Padding: 10, ForeGroundColor: .white, BackGroundColor: .secondary, CornerRadius: 10, Width: .infinity, MinHeight: 40, MaxHeight: 40, Alignment: .center)
            })
            .padding(.top, 30)

            NavigationButton(action: {
                remove_userdeaultsData()
            }, destination: {
                LoginView()
            }, label: {
                Text("Logout")
                    .setCustomViewStyle(Padding: 10, ForeGroundColor: .white, BackGroundColor: .secondary, CornerRadius: 10, Width: .infinity, MinHeight: 40, MaxHeight: 40, Alignment: .center)
            })
            
            Spacer()
            
        })
        .padding()
        .navigationTitle("Profile")
    }
}

struct ProfileView_Previews: PreviewProvider {
    static var previews: some View {
        ProfileView()
    }
}



//        .navigationBarBackButtonHidden(true)
//        .navigationViewStyle(StackNavigationViewStyle())
//        .background(TabBarAccessor { tabbar in   // << here !!
//            self.tabBar = tabbar
//            self.tabBar?.isHidden = true
//
//        })
