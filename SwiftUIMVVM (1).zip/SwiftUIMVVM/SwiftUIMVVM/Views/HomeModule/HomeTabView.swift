//
//  HomeTabView.swift
//  SwiftUIMVVM
//
//  Created by IC-MAC004 on 3/24/21.
//

import SwiftUI

struct HomeTabView: View {
    
    @State var selectedIndex = 0
    
    init() {
       
    }
    
    var body: some View {
        TabView (selection: self.$selectedIndex,
                 content:  {
                    
                    NavigationView {
                        InvoiceView()
                    }
                    .tabItem {
                        Image.tab_invoiceImage
                        Text("Invoice")
                    }
                    .tag(0)
                    .navigationBarHidden(true)
                    
                    NavigationView {
                        ProfileView()
                    }
                    .tabItem {
                        Image.tab_profileImage
                        Text("Profile")
                    }
                    .tag(1)
                    .navigationBarHidden(true)
                    
//                    .navigationBarBackButtonHidden(true)
                    
                 })
            .accentColor(.red)
            .navigationBarBackButtonHidden(true)
//            .tabViewStyle(PageTabViewStyle())
        
    }
}

struct HomeTabView_Previews: PreviewProvider {
    static var previews: some View {
        HomeTabView()
    }
}
