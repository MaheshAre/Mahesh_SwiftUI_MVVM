//
//  BlendView.swift
//  SwiftUIMVVM
//
//  Created by IC-MAC004 on 8/25/21.
//

import SwiftUI

struct BlendView: View {
    var body: some View {
    
        VStack(alignment: .center, spacing: 10, content: {
            
            ZStack {
                Image("nature1")
                    .resizable()
                    .scaledToFit()


                Image("nature2")
                    .scaledToFit()
                    .blendMode(.luminosity)
            }

            HStack {
                Image("nature1")
                    .resizable()
                    .scaledToFit()

                Image("nature2")
                    .resizable()
                    .scaledToFit()
            }
            Spacer()
            
        })
        .padding(10)
        .navigationTitle("BlendMode View")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct BlendView_Previews: PreviewProvider {
    static var previews: some View {
        BlendView()
    }
}
