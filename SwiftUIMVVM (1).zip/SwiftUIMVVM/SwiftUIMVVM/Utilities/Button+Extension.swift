//
//  Button+Extension.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 3/22/21.
//

import Foundation
import SwiftUI

//MARK:- Custom Buttons
struct NavigationButton<Destination: View, Label: View>: View {
    
    var action: () -> Void = { }
    var destination: () -> Destination
    var label: () -> Label
    
    @State private var isActive: Bool = false
    
    var body: some View {
        Button(action: {
            self.action()
            self.isActive.toggle()
        }) {
            self.label()
                .background(
                    ScrollView { // Fixes a bug where the navigation bar may become hidden on the pushed view
                        NavigationLink(destination: LazyDestination { self.destination() },
                                       isActive: self.$isActive){ EmptyView() }
                            .contentShape(Rectangle())
                            .navigationViewStyle(StackNavigationViewStyle())
                    }
                )
        }
    }
}

// This view lets us avoid instantiating our Destination before it has been pushed.
struct LazyDestination<Destination: View>: View {
    var destination: () -> Destination
    var body: some View {
        self.destination()
    }
}

/*
 
 Usage:
 
 CustomUIButton(title: "Drop Down",backGroundColor: .secondaryLabel, foregroundColor: .white, cornerRed: 10, action: { (btn) in
     
     
 })
 .frame(width: screenWidth-30, height: 50, alignment: .center)
 
 */

struct CustomButtonStyle: ButtonStyle {
    
    var fontName: Enum_FontName = .HelveticaNeue_bold
    var fontSize: CGFloat = 22
    var padding: CGFloat = 10
    var backGroundColor: Color = .clear
    var foregroundColor: Color = .blue
    var cornerRed: CGFloat = 5
    var width: CGFloat = .infinity
    var height: CGFloat = 40
    var alignment: Alignment = .center
    var clickableValue: Float = 0.9
//    var animationDuration: Double?
    
    
    func makeBody(configuration: Self.Configuration) -> some View {
        
        return configuration.label
            .padding(padding)
            .frame(maxWidth: width,minHeight: height, maxHeight: height, alignment: alignment)
            .background(backGroundColor)
            .foregroundColor(foregroundColor)
            .cornerRadius(cornerRed)
            .opacity(configuration.isPressed ? 0.7 : 1)
            .scaleEffect(configuration.isPressed ? CGFloat(clickableValue) : 1)
            .font(.custom(fontName.rawValue, fixedSize: fontSize))
            
        
        //            .animation(.easeInOut(duration: animationDuration ?? 0.0))
        
    }
}

struct CustomUIButton: UIViewRepresentable {
    let title: String
    
    var fontName: Enum_FontName = .HelveticaNeue_bold
    var fontSize: CGFloat = 22
    var backGroundColor: UIColor = .clear
    var foregroundColor: UIColor = .blue
    var cornerRed: CGFloat = 5
    
    let action: (UIButton) -> ()

    var ntPillButton = UIButton()//NTPillButton(type: .filled, title: "Start Test")

    func makeCoordinator() -> Coordinator { Coordinator(self) }

    class Coordinator: NSObject {
        var parent: CustomUIButton

        init(_ uiButton: CustomUIButton) {
            self.parent = uiButton
            super.init()
        }

        @objc func doAction(_ sender: UIButton) {
            self.parent.action(sender)
        }
    }

    func makeUIView(context: Context) -> UIButton {
        
        let button = UIButton(type: .system)
        button.setTitle(self.title, for: .normal)
        button.addTarget(context.coordinator, action: #selector(Coordinator.doAction(_ :)), for: .touchDown)
        
        button.titleLabel?.font = UIFont(name: self.fontName.rawValue, size: self.fontSize)
        button.backgroundColor = self.backGroundColor
        button.setTitleColor(self.foregroundColor, for: .normal)
        button.layer.cornerRadius = self.cornerRed
        button.layer.masksToBounds = true
        
        return button
    }

    func updateUIView(_ uiView: UIButton, context: Context) {}
}
