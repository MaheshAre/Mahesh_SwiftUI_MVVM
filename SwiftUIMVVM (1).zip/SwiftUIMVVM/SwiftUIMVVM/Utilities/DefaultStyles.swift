//
//  DefaultStyles.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 3/22/21.
//

import Foundation
import SwiftUI

extension View {
    
    //MARK:- Default Styles

    func defaultStyle() -> some View {
        
        return self
            .buttonStyle(CustomButtonStyle(fontName: .HelveticaNeue_bold, fontSize: 20, padding: 10, backGroundColor: .secondary, foregroundColor: .white, cornerRed: 10, width: .infinity, height: 50, alignment: .center))
    }

    func default_ButtonStyle() -> some View {
        
        return self
            .buttonStyle(CustomButtonStyle(fontName: .HelveticaNeue_bold, fontSize: 20, padding: 10, backGroundColor: .secondary, foregroundColor: .white, cornerRed: 10, width: .infinity, height: 50, alignment: .center))
    }
    
    /*
     
     Usage:
     default_TextHeading(Text: "Emp ID:")
     default_Text(Text: "\(user_defaults.value(forKey: Enum_UserData.UserId.rawValue) as? String ?? "")")
     */
    
    func default_TextHeading(Text text: String = "",
                               FontName fontName: Enum_FontName = .HelveticaNeue_bold,
                               FontSize fontSize: CGFloat = 17,
                               TextColor txtColor: Color = .black,
                               Alignment alignment: Alignment = .leading,
                               CornerRadius cornerRadius: CGFloat = 5,
                               BorderWidth borderWidth: CGFloat = 0,
                               BorderColor borderColor: Color = .gray) -> some View {
        
        return customText(Text: text, FontName: fontName, FontSize: fontSize, TextColor: txtColor, Alignment: alignment, CornerRadius: cornerRadius, BorderColor: borderColor, BorderWidth: borderWidth)
    }
    
    func default_Text(Text text: String = "",
                               FontName fontName: Enum_FontName = .HelveticaNeue_regular,
                               FontSize fontSize: CGFloat = 16,
                               TextColor txtColor: Color = .black,
                               Alignment alignment: Alignment = .leading,
                               CornerRadius cornerRadius: CGFloat = 5,
                               BorderWidth borderWidth: CGFloat = 0,
                               BorderColor borderColor: Color = .gray) -> some View {
        
        return customText(Text: text, FontName: fontName, FontSize: fontSize, TextColor: txtColor, Alignment: alignment, CornerRadius: cornerRadius, BorderColor: borderColor, BorderWidth: borderWidth)
    }
}
