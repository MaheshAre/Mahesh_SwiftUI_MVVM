//
//  UITabBarHide.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 3/2/21.
//

import Foundation
import UIKit
import SwiftUI

/*
 
 Usage:
 
 import UIKit
 
 ============================================================================
 
 @State var tabBar: UITabBar? = nil
 
 .background(TabBarAccessor { tabbar in   // << here !!
     self.tabBar = tabbar
     self.tabBar?.isHidden = true
     
 })
 
 ============================================================================
 
 ///////// Some Cases
 
 .background(TabBarAccessor { tabbar in   // << here !!
     self.tabBar = tabbar
 })
 .onAppear {
     
     if let tab = self.tabBar {
         tab.isHidden = true
         self.tabBar!.isHidden = true
     }
     
     
 }
 .onDisappear {
     if let tab = self.tabBar {
         tab.isHidden = true
         self.tabBar!.isHidden = true
     }
 }
 
 */


// Helper bridge to UIViewController to access enclosing UITabBarController
// and thus its UITabBar
struct TabBarAccessor: UIViewControllerRepresentable {
    
    var callback: (UITabBar) -> Void
    private let proxyController = ViewController()

    func makeUIViewController(context: UIViewControllerRepresentableContext<TabBarAccessor>) ->
                              UIViewController {
        proxyController.callback = callback
        return proxyController
    }

    func updateUIViewController(_ uiViewController: UIViewController, context: UIViewControllerRepresentableContext<TabBarAccessor>) {
    }

    typealias UIViewControllerType = UIViewController

    private class ViewController: UIViewController {
        var callback: (UITabBar) -> Void = { _ in }

        override func viewWillAppear(_ animated: Bool) {
            super.viewWillAppear(animated)
            if let tabBar = self.tabBarController {
                self.callback(tabBar.tabBar)
            }
        }
    }
}
