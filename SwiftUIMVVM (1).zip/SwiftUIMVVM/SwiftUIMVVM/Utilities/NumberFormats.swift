//
//  NumberFormats.swift
//  SwiftUIMVVM
//
//  Created by IC-MAC004 on 3/26/21.
//

import Foundation

extension Double {
    
    func doubleFormat(FractionDigits fractionDigits: Int) -> Double {
        
        let multiplier = pow(10, Double(fractionDigits))
        return Darwin.round(self * multiplier) / multiplier
    }
    
    func toStringFormat(FractionDigits fractionDigits: Int) -> String {
        return String(format: "%0.\(fractionDigits)f", self)
    }
}

extension String {
    
    func stringFormat(FractionDigits fractionDigits: Int) -> String {
        return String(format: "%0.\(fractionDigits)f", self)
    }
    
    
}
