//
//  Constants.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 2/26/21.
//

import Foundation
import SwiftUI


let screenWidth = UIScreen.main.bounds.width
let screenHeight = UIScreen.main.bounds.height

