//
//  APIs.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 2/16/21.
//

import Foundation



struct Domains {
    
    let live = "https://apibusiness.capium.com/"
    let QA = "http://apiqa.capium.com/" //"https://reqres.in/api/" //"https://jsonplaceholder.typicode.com/"
    let testing = ""
    
    func getBaseURL() -> String {
        return self.live
    }
}

enum Enum_ApisMethods: String {
    
    case login = "account/token"
    case invoice = "v1/company/268140/invoices"
    
//    case getUsers = "users"
//    case login = "login"
//    case register = "register"
}

// https://reqres.in/api/users?page=2
