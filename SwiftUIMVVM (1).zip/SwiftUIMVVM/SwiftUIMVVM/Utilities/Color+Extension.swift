//
//  Color+Extension.swift
//  SwiftUIMVVM
//
//  Created by IC-MAC004 on 3/25/21.
//

import Foundation
import UIKit
import SwiftUI

extension Color {
    
    
}

extension UIColor {
    
    func toColor() -> Color {
        return Color(self)
    }
}
