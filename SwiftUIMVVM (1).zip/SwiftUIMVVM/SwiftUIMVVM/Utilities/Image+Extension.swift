//
//  Image+Extension.swift
//  SwiftUIMVVM
//
//  Created by IC-MAC004 on 3/25/21.
//

import Foundation
import UIKit
import SwiftUI

extension Image {
    
    static var tab_profileImage: Image {
        return Image("tab_profile")
    }
    
    static var tab_invoiceImage: Image {
        return Image("tab_invoice")
    }
}
