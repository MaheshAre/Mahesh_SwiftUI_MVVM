//
//  ViewController+Extension.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 3/11/21.
//

import Foundation
import SwiftUI
import UIKit

extension UIApplication {
    
    func endEditing() {
        sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
}

extension View {
    
    func endEditing() {
        UIApplication.shared.endEditing()
    }
}


//MARK:- StatusBar

// In XCode project Target setting set Status Ber Style -> Light

//In Info.plist -> View controller-based status bar appearance set NO

/*
 
 Usage: call in main file (ProjectnameApp.swift)
 
 .onAppear(){
 self.statusBarColorChange(color: .gray)
 }
 
 */


extension App {
    
    func setStatusBarColor(BGColor bgcolor: UIColor) {
        
        if #available(iOS 13.0, *) {
            
            let statusBar = UIView(frame: UIApplication.shared.windows.filter {$0.isKeyWindow}.first?.windowScene?.statusBarManager?.statusBarFrame ?? CGRect.zero)
            statusBar.backgroundColor = bgcolor //.blue
            statusBar.tag = 100
            UIApplication.shared.windows.filter {$0.isKeyWindow}.first?.addSubview(statusBar)
            
        } else {
            
            let statusBar = UIApplication.shared.value(forKeyPath: "statusBarWindow.statusBar") as? UIView
            statusBar?.backgroundColor = bgcolor
            
        }
    }
    
    /*
     Usage:
     
     Usage: call in main file (ProjectnameApp.swift)
     
     .onAppear(){
     self.setNavigationBar(BGColor: .gray, TitleColor: .white, TintColor: .white)
     }
     
     
     */
    
    func setNavigationBar(BGColor bgColor: UIColor, TitleColor titleColor: UIColor, TintColor tintColor: UIColor) {
        
        UINavigationBar.appearance().backgroundColor = bgColor // Large NavBar BGColor
        UINavigationBar.appearance().barTintColor = bgColor // InLine NavBar BGColor
        
        UINavigationBar.appearance().titleTextAttributes = [NSAttributedString.Key.foregroundColor : titleColor, NSAttributedString.Key.font: UIFont(name: Enum_FontName.HelveticaNeue_bold.rawValue, size: 20)!] // InLine NavBar Title Color & Default size is 17
        UINavigationBar.appearance().largeTitleTextAttributes = [NSAttributedString.Key.foregroundColor: titleColor, NSAttributedString.Key.font: UIFont(name: Enum_FontName.HelveticaNeue_bold.rawValue, size: 28)!] // Large NavBar Title Color & Default size is 34
        
        UINavigationBar.appearance().tintColor = tintColor //  back Button Color/ Items Color
        
        
        let backImage = UIImage(named: "icon_back")
        UINavigationBar.appearance().backIndicatorImage = backImage
        UINavigationBar.appearance().backIndicatorTransitionMaskImage = backImage
        UINavigationBar.appearance().backItem?.title = ""
        
        
//        let backButton1 = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
//        UINavigationBar.appearance().backItem?.backBarButtonItem = backButton1
        
        
    }
}

//MARK:- Back Swipe Gesture
extension UINavigationController: UIGestureRecognizerDelegate {
    
    override open func viewDidLoad() {
        super.viewDidLoad()
        interactivePopGestureRecognizer?.delegate = self
        
    }
    
    public func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
        return false//viewControllers.count > 1
    }
}


//MARK:- Custom AlertController
struct CustomAlertController {
    
    static func showAlertController(title: String = "", message: String, actionTitle: String, onCompletion: ((UIAlertAction)->Void)? = nil) {
        
        let alertView = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let action = UIAlertAction(title: actionTitle, style: .default) { (action) in
            onCompletion?(action)
        }
        alertView.addAction(action)
        UIWindow.keyWindow?.rootViewController?.present(alertView, animated: true, completion: nil)
    }
    
}

extension UIWindow {
    static var keyWindow: UIWindow? {
        if #available(iOS 13, *) {
            return UIApplication.shared.windows.first { $0.isKeyWindow }
        } else {
            return UIApplication.shared.keyWindow
        }
    }
}

extension UIApplication {
    
    static func getTopVC() -> UIViewController {
        
        var topvc = UIViewController()
        
        let keyWindow = UIApplication.shared.windows.filter {$0.isKeyWindow}.first

        if var topController = keyWindow?.rootViewController {
            while let presentedViewController = topController.presentedViewController {
                topController = presentedViewController
            }
            
            topvc = topController
        }
        
        return topvc
    }
}





 //MARK:- Create ViewController Functionality in ContentView and etc

 /*
  
  Usage:
  
  @Environment(\.viewController) private var viewControllerHolder: UIViewController?
  
  
  self.viewControllerHolder?.present(style: .popover, builder: {
      
      ImagePicker(sourceType: sourceType, onImagePicked: { image in
          self.selectedImage = image
      })
  })
  
  or
  
  self.viewControllerHolder?.dismiss(animated: true, completion: nil)
  
 
  */

/*

 struct ViewControllerHolder {
     weak var value: UIViewController?
 }

 struct ViewControllerKey: EnvironmentKey {
     static var defaultValue: ViewControllerHolder {
         return ViewControllerHolder(value: UIApplication.shared.windows.first?.rootViewController)

     }
 }

 extension EnvironmentValues {
     var viewController: UIViewController? {
         get { return self[ViewControllerKey.self].value }
         set { self[ViewControllerKey.self].value = newValue }
     }
 }

 extension UIViewController {
     
     func present<Content: View>(style: UIModalPresentationStyle = .automatic, @ViewBuilder builder: () -> Content) {
         
         let toPresent = UIHostingController(rootView: AnyView(EmptyView()))
         toPresent.modalPresentationStyle = style
         toPresent.rootView = AnyView(
             builder()
                 .environment(\.viewController, toPresent)
         )
         NotificationCenter.default.addObserver(forName: Notification.Name(rawValue: "dismissModal"), object: nil, queue: nil) { [weak toPresent] _ in
             toPresent?.dismiss(animated: true, completion: nil)
         }
         self.present(toPresent, animated: true, completion: nil)
     }
     
 }


*/


struct ViewControllerWrapper: UIViewControllerRepresentable {
    
    let controller: UIViewController?
    typealias UIViewControllerType = UIViewController
    
    func makeUIViewController(context: UIViewControllerRepresentableContext<ViewControllerWrapper>) -> UIViewController {
        
        guard let controller = controller else {
            return UIViewController()
        }
        
        return controller
        
    }
    
    func updateUIViewController(_ uiViewController: UIViewController, context: UIViewControllerRepresentableContext<ViewControllerWrapper>) {
        
    }
}



