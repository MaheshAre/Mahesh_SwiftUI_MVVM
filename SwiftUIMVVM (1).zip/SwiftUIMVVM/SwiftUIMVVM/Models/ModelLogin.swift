//
//  ModelLogin.swift
//  SwiftUIMVVM
//
//  Created by IC-MAC004 on 3/24/21.
//

import Foundation

struct ModelLogin: Decodable {
    
    var access_token: String?
    var token_type: String?
    var refresh_token: String?
    var UserName: String?
    var UserType: String?
    var IsVerified: String?
    var UserId: String?
    var Companies: String?
    
    var error_description: String?

}
