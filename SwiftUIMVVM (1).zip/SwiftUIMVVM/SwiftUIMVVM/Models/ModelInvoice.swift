//
//  ModelInvoice.swift
//  SwiftUIMVVM
//
//  Created by IC-MAC004 on 3/26/21.
//

import Foundation

struct ModelInvoice: Decodable {
    
    var Count: Int?
    var Result: [InvoiceResponse]?
    var Status: Bool?
    var Message: String?
    var Errors: String?
}

struct InvoiceResponse: Decodable {
    
    var Id: Double?
    var ContactName: String?
    var VNo: String?
    var VDate: String?
    var DueDate: String?
    var CurrencyCode: String?
    var CurrencySymbol: String?
    var TotalAmount: Double?
    var BalanceRemaining: Double?
    var IsEditable: Bool?
    var `Type`: String?
    var CurrencyRate: Float?
    var CurrencyId: Double?
}
