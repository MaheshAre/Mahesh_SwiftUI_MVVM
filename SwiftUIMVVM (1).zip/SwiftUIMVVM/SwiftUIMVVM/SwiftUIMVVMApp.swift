//
//  SwiftUIMVVMApp.swift
//  SwiftUIMVVM
//
//  Created by IC-MAC004 on 3/24/21.
//

import SwiftUI

@main
struct SwiftUIMVVMApp: App {
    
    init() {
        
        IQKeyboardManager.shared.enable = true
        IQKeyboardManager.shared.shouldResignOnTouchOutside = true
    }
    
    var body: some Scene {
        WindowGroup {
            NavigationView {
                
               
                if let isLoggedIn = user_defaults.value(forKey: Enum_UserData.isLoggedIn.rawValue) as? Bool {
                    if isLoggedIn {
                        HomeTabView()
                    }
                }else {
                    LoginView()
                }
                
//                LoginView()
            }
        }
    }
}
