//
//  VMLogin.swift
//  SwiftUIMVVM
//
//  Created by IC-MAC004 on 3/24/21.
//

import Foundation
import SwiftUI

class VMLogin: ObservableObject {
    
    @Published var vmLogin: ModelLogin = ModelLogin()
    @Published var params: LoginParams = LoginParams()
 
    init() {
        
    }
    
    func serivce_login(onCompletion: @escaping(_ isFinished: Bool, _ errorMsg: String?)->Void) {
        
        let params = ["grant_type":"password", "type":"client", "password": self.params.password, "username": self.params.username]
        
//        print(params)
                
        NetworkManager.shared.createRequest(apiStr: .login, method: .post, params: params, headerContentType: .formurlencoded, isShowLoader: true) { (response, error) in
                        
            if let error = error {
                
                CustomAlertController.showAlertController(title: "Error", message: error, actionTitle: "Ok", onCompletion: nil)
                onCompletion(false, error)
            }else {
                do {
                    let jsonData = try JSONDecoder().decode(ModelLogin.self, from: response!.data!)
                    self.vmLogin = jsonData
                    
                    if let error = jsonData.error_description {
                        CustomAlertController.showAlertController(title: "Error", message: error, actionTitle: "Ok", onCompletion: nil)
                        onCompletion(false, error)
                    }
                    
                    AccessToken = self.vmLogin.access_token ?? ""
                    
                    user_defaults.setValue(self.vmLogin.access_token, forKey: Enum_UserData.access_token.rawValue)
                    user_defaults.setValue(self.vmLogin.token_type, forKey: Enum_UserData.token_type.rawValue)
                    user_defaults.setValue(self.vmLogin.refresh_token, forKey: Enum_UserData.refresh_token.rawValue)
                    user_defaults.setValue(self.vmLogin.UserName, forKey: Enum_UserData.UserName.rawValue)
                    user_defaults.setValue(self.vmLogin.UserType, forKey: Enum_UserData.UserType.rawValue)
                    user_defaults.setValue(self.vmLogin.IsVerified, forKey: Enum_UserData.IsVerified.rawValue)
                    user_defaults.setValue(self.vmLogin.UserId, forKey: Enum_UserData.UserId.rawValue)
                    user_defaults.setValue(self.vmLogin.Companies, forKey: Enum_UserData.Companies.rawValue)
                    user_defaults.setValue(true, forKey: Enum_UserData.isLoggedIn.rawValue)
                                        
                    onCompletion(true, nil)
                    
                }catch {
                    print(error)
                    onCompletion(false, error.localizedDescription)
                }
            }
                        
        }
        
    }
}

struct LoginParams {
    
    var username = "anusha.l@capium.com"
    var password = "capium@123"
}

enum Enum_UserData: String {    
    
    case access_token
    case token_type
    case refresh_token
    case UserName
    case UserType
    case IsVerified
    case UserId
    case Companies
    
    case isLoggedIn
}
