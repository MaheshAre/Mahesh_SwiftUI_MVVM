//
//  VMInvoice.swift
//  SwiftUIMVVM
//
//  Created by IC-MAC004 on 3/26/21.
//

import Foundation
import Combine

class VMInvoice: ObservableObject {
    
    @Published var model_invoice = ModelInvoice()
    @Published var params = ParamsInvoice()
    @Published var invoiceArray = [InvoiceResponse]()
    
    func service_invoice() {
        
        let parameters = ["count": "50", "Start": "0", "ToDate": "", "type": "Invoices", "FromDate": "", "ContactId":"", "Search": ""]
        
        NetworkManager.shared.createRequest(apiStr: .invoice, method: .get, params: parameters, headerContentType: .formurlencoded, isShowLoader: true) { (response, error) in
            
            if let error = error {
                CustomAlertController.showAlertController(title: "Error", message: error, actionTitle: "Ok", onCompletion: nil)
            }else {
                do {
                    let jsonData = try JSONDecoder().decode(ModelInvoice.self, from: response!.data!)
                    self.model_invoice = jsonData
                    if let array = jsonData.Result {
                        self.invoiceArray = array
                        
                        
                    }
                }catch {
                    print(error)
                }
            }
        }
        
    }
}

struct ParamsInvoice {
    
    var count = ""
    var Start = ""
    var ToDate = ""
    var type = "Invoices"
    var FromDate = ""
    var ContactId = ""
    var Search = ""
    
}
